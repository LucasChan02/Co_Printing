Skirt/Brim Speed
====
This setting adjusts the speed of the skirt or the brim separately from the rest of the print.

The skirt or brim is usually printed rather slowly, in order to make it stick better to the build plate. Printing slower (up to a point) generally makes it stick better, but takes more time to print.

Even though the skirt and brim are printed on the first layer, this setting overrides the [Initial Layer Print Speed](speed_print_layer_0.md).