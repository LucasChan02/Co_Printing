[//]: # (Do not translate this file! While translating the main text doesn't cause any harm, translating the labels of the preferences here will cause them to stop working.)
Preferences
====
In this page you can change the behaviour of the settings guide.

[ ] Show articles in setting tooltips (requires restart)
[ ] Window always in front

Language
----
The language can be changed by clicking on the letter symbol in the top-right corner of any article.