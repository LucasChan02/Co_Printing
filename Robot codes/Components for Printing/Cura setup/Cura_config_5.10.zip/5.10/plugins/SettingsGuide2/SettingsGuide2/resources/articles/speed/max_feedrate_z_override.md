Maximum Z Speed
====
This setting changes the speed for all build plate movements during the print. This includes all layer changes and Z Hops.

Normally the speed of the build plate movements are determined by the firmware, which lets it move as fast as possible.

**[Spiralize Outer Contours](../blackmagic/magic_spiralize.md) is not affected by this setting, even if it causes the printer to move the build plate continuously during printing.**