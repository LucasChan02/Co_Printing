Prime Tower Speed
====
This setting configures the speed at which the prime tower is printed.

It's usually good to print the prime tower at a similar speed as the rest of the print, so that the material gets primed properly. However, printing the prime tower slower will make it more stable as well, which can be useful for runny materials or very tall prints.