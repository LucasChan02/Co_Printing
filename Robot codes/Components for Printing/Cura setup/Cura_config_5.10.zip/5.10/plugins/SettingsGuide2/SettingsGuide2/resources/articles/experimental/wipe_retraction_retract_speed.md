Wipe Retraction Retract Speed
====
This setting configures how fast the material is retracted for the wiping procedure. This can be configured separately from the ordinary [retraction retract speed](../travel/retraction_retract_speed.md).

Since any material that is oozed from the nozzle during this wipe procedure will be wiped off anyway, the retraction speed may be reduced somewhat for this procedure compared to the rest of the print. This reduces wear on the filament.