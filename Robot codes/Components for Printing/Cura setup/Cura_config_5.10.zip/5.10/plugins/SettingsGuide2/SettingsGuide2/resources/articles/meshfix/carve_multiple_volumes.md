Remove Mesh Intersection
====
If multiple meshes overlap with each other, they would normally just both get printed, resulting in overextrusion. When this setting is enabled, one of the meshes gets carved out by the other. This way there will be no overextrusion, and the result will look just the same on the outside.